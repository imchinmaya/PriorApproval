'use client';

//import { Card, CardContent, CardHeader, Checkbox, Divider, FormControl, FormControlLabel, Grid, InputLabel, MenuItem, OutlinedInput, Select } from '@mui/material';
import * as React from 'react';
import CardContent from '@mui/material/CardContent';
import CardHeader from '@mui/material/CardHeader';
import Divider from '@mui/material/Divider';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import OutlinedInput from '@mui/material/OutlinedInput';
import Select from '@mui/material/Select';
import Grid from '@mui/material/Unstable_Grid2';
import { Card } from '@mui/material';

export function DefineConfigParameters({ configParameters, updateWizardData, onClientEnvironmentChange }): React.JSX.Element {
    const [mscCode, setMscCode] = React.useState({
        multiSourceCollected: false,
        singleSourceLicensed: false,
        // ... other options
    });

    const clientEnvironments = [
        { value: 'bk1', label: 'Book1' },
        { value: 'bk2', label: 'Book2' },
        { value: 'oth', label: 'Others' }
    ] as const;

    const exclusionsToPay = [
        { value: 'bk1', label: 'Book1' },
        { value: 'bk2', label: 'Book2' },
        { value: 'oth', label: 'Others' }
    ] as const;

    const [recordType, setRecordType] = React.useState('');

    // Handlers for form controls
    const handleInputChange = (event) => {
        const { name, value } = event.target;
        updateWizardData('configParameters', name, value);
        if (name === 'clientEnvironment') {
          onClientEnvironmentChange(value);
        }
      };

    // const handleInputChange = (event: any) => {
    //     const { name, value } = event.target;
    //     switch (name) {
    //         case 'clientEnvironment':
    //             setClientEnvironment(value);
    //             break;
    //         case 'configType':
    //             setConfigType(value);
    //             break;
    //         case 'inputType':
    //             setInputType(value);
    //             break;
    //         case 'exclusionToPay':
    //             setExclusionToPay(value);
    //             break;
    //         case 'gcnGpiCrosswalk':
    //             setGcnGpiCrosswalk(value);
    //             break;
    //         case 'eligibilityLookup':
    //             setEligibilityLookup(value);
    //             break;
    //         case 'recordType':
    //             setRecordType(value);
    //             break;
    //         case 'dateFormat':
    //             setDateFormat(value);
    //             break;
    //         case 'pbmId':
    //             setPbmId(value);
    //             break;
    //         case 'goLiveDate':
    //             setGoLiveDate(value);
    //             break;
    //         case 'fileHeader':
    //             setFileHeader(value);
    //             break;
    //         case 'fileFooter':
    //             setFileFooter(value);
    //             break;
    //         case 'applyDateTerm':
    //             setApplyDateTerm(value);
    //             break;
    //         case 'consentyxOption':
    //             setConsentyxOption(value);
    //             break;
    //         default:
    //             break;
    //     }
    // };

    const handleCheckboxChange = (event: any) => {
        const { name, checked } = event.target;
        setMscCode(prevMscCode => ({ ...prevMscCode, [name]: checked }));
    };

    const handleSubmit = (event: any) => {
        event.preventDefault();
        // Submit your form values somewhere or move to the next step
    };

    // Render the form
    return (
        <form
            onSubmit={(event) => {
                event.preventDefault();
            }}
        >
            <Card>
                <CardHeader subheader="The information can be edited" title="Define Config Parameters" />
                <Divider />
                <CardContent>
                    <Grid container spacing={3}>
                        <Grid md={6} xs={12}>
                            <FormControl fullWidth required>
                                <InputLabel>Client Environment</InputLabel>
                                <Select value={configParameters.clientEnvironment} label="Client Environment" name="clientEnvironment" onChange={handleInputChange} variant="outlined">
                                    {clientEnvironments.map((option) => (
                                        <MenuItem key={option.value} value={option.value}>
                                            {option.label}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid md={6} xs={12}>
                            <FormControl fullWidth required>
                                <InputLabel>Config Type</InputLabel>
                                <OutlinedInput value={configParameters.configType} onChange={handleInputChange} label="Config Type" name="configType" />
                            </FormControl>
                        </Grid>
                        <Grid md={6} xs={12}>
                            <FormControl fullWidth required>
                                <InputLabel>Input Type</InputLabel>
                                <OutlinedInput value={configParameters.inputType} onChange={handleInputChange} label="Input Type" name="inputType" />
                            </FormControl>
                        </Grid>
                        <Grid md={6} xs={12}>
                            <FormControl fullWidth required>
                                <InputLabel>GCN GPI Crosswalk</InputLabel>
                                <Select value={configParameters.gcnGpiCrosswalk} onChange={handleInputChange} label="GCN GPI Crosswalk" name="gcnGpiCrosswalk" variant="outlined">
                                    <MenuItem value="Y">Yes</MenuItem>
                                    <MenuItem value="N">No</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid md={6} xs={12}>
                            <FormControl fullWidth required>
                                <InputLabel>Eligibility Lookup</InputLabel>
                                <Select value={configParameters.eligibilityLookup} onChange={handleInputChange} label="Eligibility Lookup" name="eligibilityLookup" variant="outlined">
                                    <MenuItem value="Y">Yes</MenuItem>
                                    <MenuItem value="N">No</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid md={6} xs={12}>
                            <FormControl fullWidth required>
                                <InputLabel>Exclusion to Pay</InputLabel>
                                <Select value={configParameters.exclusionToPay} onChange={handleInputChange} label="Exclusion to Pay" name="exclusionToPay" variant="outlined">
                                    <MenuItem value="Y">Yes</MenuItem>
                                    <MenuItem value="N">No</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        {configParameters.clientEnvironment !== 'bk2'? <Grid md={6} xs={12}>
                            <FormControl fullWidth required>
                            <InputLabel>Exclusion MSC Code List</InputLabel>
                                <Select value={mscCode} onChange={handleCheckboxChange} label="Exclusion MSC Code List" name="mscCode" variant="outlined">
                                    <MenuItem value="M">M(Single-Source, Colicensed)</MenuItem>
                                    <MenuItem value="N">N(Single-Source Product)</MenuItem>
                                    <MenuItem value="Y">Y(Multi-Source Product)</MenuItem>
                                    <MenuItem value="O">O(Multi-Source Originator)</MenuItem>
                                    <MenuItem value="B">B(All Brand Drugs)</MenuItem>
                                    <MenuItem value="*">*(All Drugs)</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>:null}
                        <Grid md={6} xs={12}>
                            <FormControl fullWidth required>
                                <InputLabel>Record Type</InputLabel>
                                <Select value={configParameters.recordType} onChange={handleInputChange} label="Record Type" name="recordType" variant="outlined">
                                    {exclusionsToPay.map((option) => (
                                        <MenuItem key={option.value} value={option.value}>
                                            {option.label}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid md={6} xs={12}>
                            <FormControl fullWidth required>
                                <InputLabel>Date Format</InputLabel>
                                <OutlinedInput value={configParameters.dateFormat} onChange={handleInputChange} label="Date Format" name="dateFormat" />
                            </FormControl>
                        </Grid>
                        <Grid md={6} xs={12}>
                            <FormControl fullWidth required>
                                <InputLabel>PBM ID</InputLabel>
                                <Select value={configParameters.pbmId} onChange={handleInputChange} label="PBM ID" name="pbmId" variant="outlined">
                                    <MenuItem value="CUSTOM">Custom</MenuItem>
                                    <MenuItem value="ESI500">ESI500</MenuItem>
                                    <MenuItem value="ESI600">ESI600</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid md={6} xs={12}>
                            <FormControl fullWidth required>
                                <InputLabel>Go Live Date (YYMMDD)</InputLabel>
                                <OutlinedInput value={configParameters.goLiveDate} onChange={handleInputChange} label="Go Live Date" name="goLiveDate" />
                            </FormControl>
                        </Grid>
                        {configParameters.clientEnvironment !== 'bk2'? <Grid md={6} xs={12}>
                            <FormControl fullWidth required>
                                <InputLabel>Apply Term Date</InputLabel>
                                <Select value={configParameters.applyDateTerm} onChange={handleInputChange} label="Exclusion to Pay" name="applyDateTerm" variant="outlined">
                                    <MenuItem value="Y">Yes</MenuItem>
                                    <MenuItem value="N">No</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>:null}
                        {configParameters.clientEnvironment !== 'bk2'? <Grid md={6} xs={12}>
                            <FormControl fullWidth required>
                                <InputLabel>Consentyx Option</InputLabel>
                                <Select value={configParameters.consentyxOption} onChange={handleInputChange} label="Consentyx Option" name="consentyxOption" variant="outlined">
                                    <MenuItem value="Y">Yes</MenuItem>
                                    <MenuItem value="N">No</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>:null}
                        <Grid md={6} xs={12}>
                            <FormControl fullWidth required>
                                <InputLabel>File Header</InputLabel>
                                <Select value={configParameters.fileHeader} onChange={handleInputChange} label="File Header" name="fileHeader" variant="outlined">
                                    <MenuItem value="Y">Yes</MenuItem>
                                    <MenuItem value="N">No</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid md={6} xs={12}>
                            <FormControl fullWidth required>
                                <InputLabel>File Footer</InputLabel>
                                <Select value={configParameters.fileFooter} onChange={handleInputChange} label="File Footer" name="fileFooter" variant="outlined">
                                    <MenuItem value="Y">Yes</MenuItem>
                                    <MenuItem value="N">No</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                    </Grid>
                </CardContent>
                <Divider />
            </Card>
        </form>

    );

}